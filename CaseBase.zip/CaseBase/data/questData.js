const questData = {
    "grey": {
        num: {paper: 8},
        numUnlocks: {"basic": [2, 3]},
        blnUnlocks: ["rocks", "purple"]
    },
    "red": {},
    "blue": {},
    "purple": {
        num: {scissors: 12},
        numUnlocks: {"basic": [4]},
        blnUnlocks: ["rare", "keys", "locked"]
    }
}