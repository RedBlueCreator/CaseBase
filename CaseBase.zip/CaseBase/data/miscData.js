const miscData = {
    "cases": ["basic", "rare", "epic", "mythic", "locked"],
    "itemColumn1": ["scissors", "paper", "rocks"],
    "itemColumn2": ["amethysts", "rubies", "emeralds"],
    "itemColumn3": ["sapphires", "amber", "keys"],
    "toolRow": [],
    "tasks": ["grey", "red", "blue", "purple"],
    "codes": {
        "Who are you?": ["I can help you out... with knowledge..."],
        "Where is Viktor?": ["idk"]
    }
}